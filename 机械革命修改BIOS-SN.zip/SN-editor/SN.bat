@echo off
set SRC=%~dp0
setlocal
set uac=~uac_permission_tmp_%random%
md "%SystemRoot%\system32\%uac%" 2>nul
if %errorlevel%==0 ( rd "%SystemRoot%\system32\%uac%" >nul 2>nul ) else (
 echo set uac = CreateObject^("Shell.Application"^)>"%temp%\%uac%.vbs"
 echo uac.ShellExecute "%~s0","","","runas",1 >>"%temp%\%uac%.vbs"
 echo WScript.Quit >>"%temp%\%uac%.vbs"
 "%temp%\%uac%.vbs" /f
 del /f /q "%temp%\%uac%.vbs" & exit )
endlocal
:Admin

@echo off&setlocal enabledelayedexpansion
set /p s=please input sn:

for /l %%s in (0,1,100) do (
set /a z+=1
if not "!s:~%%s,1!"=="" (
set c=!z!
:echo %c%
:set /p=%c%
)
)
echo "The SN entered is" %s%
echo "The SN length entered is" %c%
timeout 3
if not %c%==18 (
 echo "error：SN digit mismatch"
goto end
) else (
 echo "Now Start writing SN......"
AMIDEWINx64.EXE /SS %s%
echo "writing SN success "
timeout 5
)
:END